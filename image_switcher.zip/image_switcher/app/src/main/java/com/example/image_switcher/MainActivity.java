package com.example.image_switcher;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button b1,b2;
    ImageView iv;
    boolean flag;
    int images[]={R.drawable.ic1,R.drawable.ic2,R.drawable.ic3};
    int i=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        iv = (ImageView) findViewById(R.id.img1);
        b1 = (Button) findViewById(R.id.button);
        b2=findViewById(R.id.button2);
        flag =true;
        iv.setImageResource(images[i]);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                iv.setImageResource(images[i]);
                i++;
                if(i==2)
                    i=0;
            }
        });
    b2.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            iv.setImageResource(images[i]);
            i--;
            if(i==-1)
                i=2;
        }
    });
    }
}